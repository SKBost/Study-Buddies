//
//  ViewController.swift
//  ruby
//
//  Created by mac on 12/30/20.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var Button2: UIButton!
    @IBOutlet weak var button: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        button.layer.cornerRadius = 20
        Button2.layer.cornerRadius = 20
        
    }


}

